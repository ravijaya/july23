from psmakearchive import make_archive
from glob import glob

list_of_files = glob('*.py')
print(list_of_files)
print()
make_archive('src.zip', *list_of_files)  # passing content of the list as argument