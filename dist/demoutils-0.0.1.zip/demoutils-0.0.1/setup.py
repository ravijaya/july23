from distutils.core import setup

setup(name='demoutils',
      version='0.0.1',
      packages=['demoutils'],
      author='jaya',
    )
